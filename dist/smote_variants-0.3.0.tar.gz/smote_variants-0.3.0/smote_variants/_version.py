#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 28 17:21:13 2018

@author: gykovacs
"""

__version__= '0.3.0'